import Link from "next/link";

export default function NewsDetailPage() {
  return (
    <main className="bg-slate-100 min-h-screen">

      <div className="mx-auto max-w-5xl px-6 py-10">

        <Link
          href="/"
          className="font-semibold text-blue-600 hover:underline"
        >
          ← トップへ戻る
        </Link>

        <div className="mt-8 overflow-hidden rounded-3xl bg-white shadow-lg">

          <img
            src="https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=1800"
            alt="news"
            className="h-[420px] w-full object-cover"
          />

          <div className="p-10">

            <span className="rounded-full bg-red-600 px-4 py-2 text-sm font-bold text-white">
              国内
            </span>

            <h1 className="mt-6 text-5xl font-black leading-tight text-slate-900">

              AIが選ぶ
              <br />
              今日もっとも重要な国内ニュース

            </h1>

                        <div className="mt-8 flex flex-wrap items-center gap-4">

              <span className="rounded-full bg-emerald-100 px-4 py-2 text-sm font-bold text-emerald-700">
                AI要約
              </span>

              <span className="text-sm font-medium text-slate-500">
                更新：2026年8月3日 12:30
              </span>

            </div>

            <div className="mt-10 rounded-2xl border-l-4 border-blue-600 bg-slate-50 p-8">

              <h2 className="text-2xl font-black text-slate-900">
                🤖 AI要約
              </h2>

              <p className="mt-5 leading-8 text-slate-700">

                AIが国内ニュースを分析した結果、
                今日最も重要なニュースとして選定されました。

                要点だけを短時間で理解できるよう、
                内容を分かりやすく要約しています。

              </p>

            </div>

            <article className="prose mt-10 max-w-none prose-slate">

              <p>

                ここにRSSから取得した記事本文が表示されます。

              </p>

              <p>

                将来的にはOpenAI APIで要約した文章や、
                元記事へのリンクを表示します。

              </p>

              <p>

                RSS・AI・自動投稿を組み合わせることで、
                ニュースサイトを24時間自動更新できるようになります。

              </p>

            </article>

                        <div className="mt-14 border-t border-slate-200 pt-10">

              <h2 className="text-3xl font-black text-slate-900">
                関連記事
              </h2>

              <div className="mt-8 grid gap-6 md:grid-cols-2">

                <div className="rounded-2xl border border-slate-200 bg-white p-6 transition hover:shadow-lg">

                  <span className="rounded-full bg-blue-600 px-3 py-1 text-xs font-bold text-white">
                    国内
                  </span>

                  <h3 className="mt-4 text-xl font-bold text-slate-900">
                    AIが選ぶ注目ニュース
                  </h3>

                  <p className="mt-3 text-slate-600">
                    関連するニュース記事を表示します。
                  </p>

                </div>

                <div className="rounded-2xl border border-slate-200 bg-white p-6 transition hover:shadow-lg">

                  <span className="rounded-full bg-green-600 px-3 py-1 text-xs font-bold text-white">
                    スポーツ
                  </span>

                  <h3 className="mt-4 text-xl font-bold text-slate-900">
                    最新スポーツニュース
                  </h3>

                  <p className="mt-3 text-slate-600">
                    RSSから取得した関連記事を表示します。
                  </p>

                </div>

              </div>

              <div className="mt-10">

                <Link
                  href="/"
                  className="inline-flex items-center rounded-full bg-slate-900 px-6 py-3 font-bold text-white transition hover:bg-blue-600"
                >
                  ← トップページへ戻る
                </Link>

              </div>

            </div>

          </div>

        </div>

      </div>

    </main>
  );
}