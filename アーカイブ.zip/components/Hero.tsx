
export default function Hero() {
  return (
    <section className="mb-12">
      <div className="relative overflow-hidden rounded-[32px] shadow-2xl">

        <img
  src="https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=2000"
  alt="Hero"
  className="h-[650px] w-full object-cover"
/>

        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-black/20" />

        <div className="absolute left-10 top-10">

          <span className="rounded-full bg-red-600 px-6 py-2 text-sm font-bold text-white">
            🔴 BREAKING NEWS
          </span>

        </div>

        <div className="absolute bottom-14 left-10 max-w-4xl">

          <span className="rounded-full bg-blue-600 px-4 py-2 text-sm font-bold text-white">
            AI PICK
          </span>

          <h1 className="mt-6 text-6xl font-black leading-tight text-white">
            AIが選ぶ
            <br />
            今日もっとも重要な国内ニュース
          </h1>

          <p className="mt-8 max-w-3xl text-xl leading-9 text-white">
            AIが国内ニュースを自動収集し、
            重要度を分析して分かりやすく要約。
            忙しい人でも3分で最新情報を把握できます。
          </p>

          <div className="mt-10 flex flex-wrap gap-4">

                      <button className="rounded-full bg-blue-600 px-8 py-4 text-lg font-bold text-white transition hover:bg-blue-700">
              記事を読む
            </button>

            <button className="rounded-full border-2 border-white px-8 py-4 text-lg font-bold text-white transition hover:bg-white hover:text-slate-900">
              AI要約を見る
            </button>

          </div>

          <div className="mt-10 flex flex-wrap items-center gap-5">

            <span className="rounded-full bg-white/20 px-4 py-2 text-sm font-medium text-white backdrop-blur">
              🕒 更新：2026年8月3日
            </span>

            <span className="rounded-full bg-black/50 px-4 py-2 text-sm font-medium text-white backdrop-blur">
              👁 24,568 Views
            </span>

            <span className="rounded-full bg-emerald-500 px-4 py-2 text-sm font-bold text-white">
              AI要約済み
            </span>

          </div>

          <div className="mt-12 grid gap-4 md:grid-cols-3">

                        <div className="rounded-2xl border border-white/20 bg-white/10 p-5 backdrop-blur">

              <p className="text-xs font-bold uppercase tracking-widest text-blue-300">
                国内
              </p>

              <h3 className="mt-3 text-lg font-bold text-white">
                日経平均株価が今年最高値を更新
              </h3>

              <p className="mt-3 text-sm leading-6 text-white/90">
                AIが重要ポイントだけを分かりやすく要約。
                3分で内容を把握できます。
              </p>

            </div>

            <div className="rounded-2xl border border-white/20 bg-white/10 p-5 backdrop-blur">

              <p className="text-xs font-bold uppercase tracking-widest text-pink-300">
                芸能
              </p>

              <h3 className="mt-3 text-lg font-bold text-white">
                話題の新作映画が全国公開
              </h3>

              <p className="mt-3 text-sm leading-6 text-white/90">
                SNSで話題の映画情報をAIが要約。
              </p>

            </div>

            <div className="rounded-2xl border border-white/20 bg-white/10 p-5 backdrop-blur">

              <p className="text-xs font-bold uppercase tracking-widest text-green-300">
                スポーツ
              </p>

              <h3 className="mt-3 text-lg font-bold text-white">
                日本代表が劇的勝利
              </h3>

              <p className="mt-3 text-sm leading-6 text-white/90">
                試合のポイントをAIが分かりやすく解説。
              </p>

            </div>

                      </div>

        </div>

      </div>

    </section>
  );
} 