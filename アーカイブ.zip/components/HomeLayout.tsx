import Hero from "./Hero";
import NewsGrid from "./NewsGrid";
import Sidebar from "./Sidebar";
import Footer from "./Footer";

export default function HomeLayout() {
  return (
    <main className="bg-slate-100">
      <div className="mx-auto max-w-7xl px-6 py-8">
        <Hero />

        <div className="mt-10 grid grid-cols-1 gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <NewsGrid />
          </div>

          <Sidebar />
        </div>
      </div>

      <Footer />
    </main>
  );
}