import { prisma } from "@/lib/prisma";
import { fetchNews } from "@/lib/fetchNews";

export async function syncNews() {
  const items = await fetchNews();

  for (const item of items) {
    const title = item.title ?? "";
    const sourceUrl = item.link ?? "";

    if (!sourceUrl) continue;

    const exists = await prisma.news.findUnique({
      where: {
        sourceUrl,
      },
    });

    if (exists) continue;

    await prisma.news.create({
      data: {
        title,
        sourceUrl,
        source: "Google News",
        publishedAt: item.pubDate
          ? new Date(item.pubDate)
          : null,
      },
    });
  }

  return {
    success: true,
    count: items.length,
  };
}